# a test file for t/lib/warnings/op
eval "use v5.14;";
1;
