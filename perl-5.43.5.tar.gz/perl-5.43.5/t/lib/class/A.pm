no warnings 'experimental::class';
use feature 'class';
class A {}
1;
