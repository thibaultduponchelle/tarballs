no warnings 'experimental::class';
use feature 'class';
class A::B :isa(A) {}
1;
