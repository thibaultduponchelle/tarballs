# for use by caller.t for GH #15109 and other tests
package Apack;
use Bpack;
1;
